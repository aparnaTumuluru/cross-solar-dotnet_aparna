﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using CrossSolar.Controllers;
using CrossSolar.Domain;
using CrossSolar.Models;
using CrossSolar.Repository;
using Microsoft.AspNetCore.Mvc;
using Moq;
using Xunit;


namespace CrossSolar.Tests.Controller
{
	public class AnalyticsControllerTests
	{
		public AnalyticsControllerTests()
		{
			_analyticsController = new AnalyticsController(_analyticsRepositoryMock.Object, _panelRepositoryMock.Object);
		}

		private readonly AnalyticsController _analyticsController;
		private readonly PanelController _panelController;

		private readonly Mock<IAnalyticsRepository> _analyticsRepositoryMock = new Mock<IAnalyticsRepository>();
		private readonly Mock<IPanelRepository> _panelRepositoryMock = new Mock<IPanelRepository>();


		[Fact]
		public async Task Post_ShouldCreateOneHourEM()
		{
			OneHourElectricityModel oneHourElectricityModel = new OneHourElectricityModel
			{
				KiloWatt = 100
			};

			var result  = await _analyticsController.Post("XXXX1111YYYY2222", oneHourElectricityModel);

			Assert.NotNull(result);

			var createdResult = result as CreatedResult;

			Assert.NotNull(createdResult);
			Assert.Equal(201, createdResult.StatusCode);

		}

		[Fact]

		public async void AnalyticsControllerTests_Day()
		{

			var panel = new PanelModel
			{
				Brand = "Areva",
				Latitude = 12.345678,
				Longitude = 98.7655432,
				Serial = "XXXX1111YYYY2222"
			};

			var panelRegistered = await _panelController.Register(panel);

			//inserting  records  to table

			await _analyticsController.Post("XXXX1111YYYY2222", new OneHourElectricityModel()
			{
				KiloWatt = 100,
				DateTime = new DateTime(1985, 11, 10)
		});

			var result = _analyticsController.DayResults("XXXX1111YYYY2222").Result;
			Assert.IsType<OkObjectResult>(result);
			var finalrecord = result as OkObjectResult;

			var resp = (finalrecord.Value as OneDayElectricityModel);

			Assert.Equal(100, resp.Average);
			Assert.Equal(100, resp.Minimum);
			Assert.Equal(100, resp.Maximum);

		}



	}
}
